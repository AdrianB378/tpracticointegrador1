package com.todocodeacademy.tpintegrador1;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Tpintegrador1Application {

	public static void main(String[] args) {
		SpringApplication.run(Tpintegrador1Application.class, args);
	}

}
